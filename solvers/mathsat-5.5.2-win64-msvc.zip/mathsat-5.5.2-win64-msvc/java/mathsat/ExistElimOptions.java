package mathsat;

public class ExistElimOptions {
    public int toplevel_propagation;
    public int boolean_simplifications;
    public int remove_redundant_constraints;
}
